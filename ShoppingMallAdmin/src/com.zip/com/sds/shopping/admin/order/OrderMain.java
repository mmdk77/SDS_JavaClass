package com.sds.shopping.admin.order;

import java.awt.Color;

import javax.swing.JPanel;

public class OrderMain extends JPanel{
	public OrderMain() {
		setBackground(Color.GREEN);
		setVisible(false);
	}
}
