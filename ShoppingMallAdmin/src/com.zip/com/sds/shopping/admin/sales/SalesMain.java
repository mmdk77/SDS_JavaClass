package com.sds.shopping.admin.sales;

import java.awt.Color;

import javax.swing.JPanel;

public class SalesMain extends JPanel{
	public SalesMain() {
		setBackground(Color.RED);
		setVisible(false);
	}
}
