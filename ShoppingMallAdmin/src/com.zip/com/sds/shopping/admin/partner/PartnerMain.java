package com.sds.shopping.admin.partner;

import java.awt.Color;

import javax.swing.JPanel;

public class PartnerMain extends JPanel{
	public PartnerMain() {
		setBackground(Color.BLUE);
		setVisible(false);
	}
}
