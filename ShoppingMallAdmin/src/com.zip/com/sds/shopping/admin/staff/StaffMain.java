package com.sds.shopping.admin.staff;

import java.awt.Color;

import javax.swing.JPanel;

public class StaffMain extends JPanel{
	public StaffMain() {
		setBackground(Color.PINK);
		setVisible(false);
	}
}
