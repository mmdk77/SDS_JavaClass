package com.sds.shopping.admin.member;

import java.awt.Color;

import javax.swing.JPanel;

public class MemberMain extends JPanel{
	public MemberMain() {
		setBackground(Color.CYAN);
		setVisible(false);
	}
}
